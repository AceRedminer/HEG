package Exercice1;

public class Voiture {
    String marque;
    String modele;
    int annee;

    public Voiture(String mar, String mod, int an){
        this.marque = mar;
        this.modele = mod;
        this.annee = an;
    }
}
