package Exercice1;

public class Maison {
    int surface;
    int nbPieces;
    boolean location;
    int prix;

    public Maison(int surface, int nbPieces, boolean location, int prix){
        this.surface = surface;
        this.nbPieces = nbPieces;
        this.location = location;
        this.prix = prix;
    }
}
